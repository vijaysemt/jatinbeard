<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <p>fname: {{ $data['fname'] }}</p>
    <p>lname: {{ $data['lname'] }}</p>
    <p>email: {{ $data['email'] }}</p>
    <p>mobile: {{ $data['mobile'] }}</p>
    <p>course: {{ $data['course'] }}</p>
    <p>message: {{ $data['message'] }}</p>
</body>

</html>
