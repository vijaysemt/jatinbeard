@include('header-all')


<main>

    <!-- Blog Posts start-->
    <section class="pt-60" style="background: #fbfbfb;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-md-2">
                    <img src="frontend/img/achievement.gif" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </section>
    <!-- Blog Posts end-->


</main>


@include('footer')
