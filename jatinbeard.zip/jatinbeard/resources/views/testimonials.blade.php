@include('header')

<!-- About Text Content -->
<section class="about-section py-5 mt-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="mb35 text-center">Kind Words ❤️ From Our Clients </h1><br>
                <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
                <div class="elfsight-app-1543c894-d952-4764-807a-0384a2ae4561" data-elfsight-app-lazy></div>
            </div>
        </div>
    </div>
</section>

@include('footer')
