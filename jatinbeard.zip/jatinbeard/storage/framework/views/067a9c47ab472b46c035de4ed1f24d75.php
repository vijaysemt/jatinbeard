<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <!-- Begin page -->
    <div id="wrapper">
        <!-- Topbar Start -->
        <div class="navbar-custom">
            <?php echo $__env->make('layouts.components.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- end Topbar --> <!-- ========== Left Sidebar Start ========== -->
        <div class="left-side-menu">
            <?php echo $__env->make('layouts.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End Sidebar -->
            <div class="clearfix"></div>
            <!-- Left Sidebar End -->
        </div>
        <!-- END wrapper -->

        <div class="content-page">
            <div class="content">
                <!-- Start container-fluid -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-6">
                            <div>
                                <h4 class=" mb-3">Product List:-</h4>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="text-right">
                                <a href="/createproduct">
                                    <button class="btn btn-sm btn-primary">
                                        <i class="fas fa-plus"></i> Add New Product
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->

                    <!-- end row -->
                    <!-- start  -->
                    <div class="row">
                        <div class="col-lg-12 col-12">
                            <div class="table-responsive">
                                <table class="table table-hover mails m-0 table table-actions-bar table-centered">
                                    <thead>
                                        <tr>
                                            <th>Sr.no</th>
                                            <th>Image</th>
                                            <th>Cover</th>
                                            <th>Name</th>
                                            <th>Order</th>
                                            <th>Weight</th>
                                            <th>Length</th>
                                            <th>Breadth</th>
                                            <th>Height</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $sr = 0;
                                        ?>
                                        <?php $__currentLoopData = App\Models\Product::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $sr++;
                                            ?>
                                            <tr>
                                                <td><?php echo e($sr); ?></td>
                                                <td>
                                                    <img src="<?php echo e(url('admin/assets/uploads/product/home/' . $date->pimage)); ?>"
                                                        alt="" width="50px">
                                                </td>
                                                <td>
                                                    <img src="<?php echo e(url('admin/assets/uploads/product/cover/' . $date->pcover)); ?>"
                                                        alt="" width="80px">
                                                </td>
                                                <td><?php echo e($date->name); ?></td>
                                                <td> <?php echo e($date->order); ?>  </td>
                                                <td> <?php echo e($date->weight); ?>  </td>
                                                <td> <?php echo e($date->length); ?>  </td>
                                                <td> <?php echo e($date->breadth); ?>  </td>
                                                <td> <?php echo e($date->height); ?>  </td>
                                                <td>
                                                    <?php if($date->status == 0): ?>
                                                        <span class="font-weight-bold text-primary">
                                                            <?php
                                                                echo 'Visible!!';
                                                            ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="font-weight-bold text-danger">
                                                            <?php
                                                                echo 'Hidden!!';
                                                            ?>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url('updateproduct/' . $date->id . '/' . $date->name)); ?>">
                                                        <span class="btn btn-success btn-sm">
                                                            <i class="far fa-edit"></i> Update
                                                        </span>
                                                    </a>
                                                    <a href="<?php echo e(url('deleteproduct/' . $date->id .'/' . $date->name)); ?>">
                                                        <span class="btn btn-danger btn-sm">
                                                            <i class="fas fa-trash"></i> Delete
                                                        </span>
                                                    </a>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- end container-fluid -->
                    <!-- Footer Start -->
                    <footer class="footer">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                    © 2024 Jatin Beard Oil - Dashboard | All Rights Reserved. Designed by DigitalMagnetix
                                </div>
                            </div>
                        </div>
                    </footer>
                    <!-- end Footer -->
                    <!-- Button trigger modal -->


                </div>
                <!-- end content -->
            </div>
            <!-- END content-page -->



<?php echo $__env->make('layouts.components.footer-cdn-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\jatinbeard\resources\views/admin/product/index.blade.php ENDPATH**/ ?>