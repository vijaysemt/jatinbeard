<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area" style="background: #111">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-title-content ">
                        <h2 class="title text-white text-center">Jatin Beard Oil - india's best Oil</h2>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start About Area ==-->
    <section class="about-area py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about-content">
                        <div class="section-title mb-0">
                            <h2 class="title mb-4">Jatin Beard Oil About </h2>
                        </div>
                        <p class="mb-15">Jatin Beard , The People's Brand, is here to offer the best solutions for all your SKIN & HAIR problems. A prominent and homegrown Indian brand, Jatin Beard has brought in sophisticated amenities for our clients in the skin and hair department.
                        <br>We deliver a wide variety of men's and women's skincare, haircare, well-priced and genuine products. We guarantee you to make your life much easier by shipping directly to your doorway. In addition, we ship to almost every pin code with safety precautions by utilizing the services of reliable delivery partners.</p>
                        
                        <ul>
                            <li class="mb-3"><i class="fas fa-arrow-circle-right text-success"></i> &nbsp; Jatin Beard products provide the finest, purest, and genuine solutions to our clients. An amalgamation of 100% authentic natural raw materials, directly sourced from the warehouse and delivered to your doorstep with a click away.</li>
                            <li class="mb-3"><i class="fas fa-arrow-circle-right text-success"></i> &nbsp;  Jatin Beard products are now available in our stores and online, We are live on E-Commerce Platform. Additionally, we export products to various countries in the world. So be the first to shop our exclusive drop!</li>
                            <li class="mb-3"><i class="fas fa-arrow-circle-right text-success"></i> &nbsp;  Make an empowered choice in your Skin & Haircare regimen that doesn't cost the earth. Shop Jatin Beard now.</li>
                        </ul>
                    </div>
                </div>
                <!--<div class="col-lg-6">-->
                <!--    <div class="thumb thumb-hover mt-md-30">-->
                <!--        <img src="frontend/img/about/1.webp" alt="Olivine-Image">-->
                <!--        <div class="img-content">-->
                <!--            <h3>2025</h3>-->
                <!--            <span>Oil</span>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>
    <!--== End About Area ==-->
    
    <!--== End Brand Logo Area ==-->
</main>




<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\jatinbeardddddssee\resources\views/about-us.blade.php ENDPATH**/ ?>