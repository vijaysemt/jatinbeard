<!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>
        <!-- Vendor js -->
        <script src="<?php echo e(url('admin/assets/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin/assets/libs/morris-js/morris.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin/assets/libs/raphael/raphael.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin/assets/js/pages/dashboard.init.js')); ?>"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <?php if(session('status')): ?>
            <script>
                swal("<?php echo e(session('status')); ?>");
            </script>
        <?php endif; ?>

        <!-- App js -->
        <script src="<?php echo e(url('admin/assets/js/app.min.js')); ?>"></script>
    </body>

</html>

<?php /**PATH C:\xampp\htdocs\jatinbeard\resources\views/layouts/components/footer-cdn-master.blade.php ENDPATH**/ ?>