<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--== Start Product Tab Area Wrapper ==-->
<section class="product-area product-default-area" style="background:#f2f2f2;">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="product-tab-content" data-aos="fade-up" data-aos-duration="1000">
                    <div class="row">
                        <div class="col-xl-12 col-md-12">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="popular-product" role="tabpanel"
                                    aria-labelledby="new-product-tab">
                                    <div class="row">

                                        <?php $__currentLoopData = App\Models\Product::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12 col-sm-3">
                                                <!-- Start Product Item -->
                                                <div class="product-item">
                                                    <div class="product-thumb">
                                                        <a href="<?php echo e(url('product', $item->id . '/' . $item->name)); ?>">
                                                            <img src="<?php echo e(url('admin/assets/uploads/product/home/' . $item->pimage)); ?>"
                                                                alt="" width="50px">
                                                        </a>
                                                    </div>
                                                    <div class="product-info">
                                                        <div class="row align-items-end mx-0">
                                                            <h4 class="title text-capitalize">
                                                                <a
                                                                    href="<?php echo e(url('product', $item->id . '/' . $item->name)); ?>"><?php echo e($item->name); ?></a>
                                                            </h4>
                                                            <div class="small fw-bold">
                                                                <?php if($item->status == 0): ?>
                                                                    <span class="font-weight-bold text-danger">
                                                                        <?php
                                                                            echo 'In stock';
                                                                        ?>
                                                                    </span>
                                                                <?php else: ?>
                                                                    <span class="font-weight-bold text-danger">
                                                                        <?php
                                                                            echo 'Out of stock';
                                                                        ?>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="prices">
                                                                <span class="price">Rs.<?php echo e($item->price); ?>/-</span>
                                                                <!--<span-->
                                                                <!--    class="price-old">₹<?php echo e($item->price); ?>-->
                                                                <!--</span>-->
                                                            </div>
                                                            <a href="<?php echo e(url('add-to-cart', $item->id)); ?>"
                                                                class="btn btn-secondary">Add to Cart</a>
                                                            <button
                                                                class="btn btn-success w-100 border-0 btn-whatesapp">
                                                                <a target="_blank" class="action-cart text-white"
                                                                    href="https://wa.me/+917307051100?text=Hi, I am Interested to buy this product, Please guide me <?php echo e($item['name']); ?> price:- <?php echo e($item['price']); ?> <?php echo e(url('product/' . $item['id'] . '/' . $item['name'])); ?>">
                                                                    <i class="icofont-whatsapp"></i> Order on whatesapp
                                                                </a>
                                                            </button>
                                                            <img src="<?php echo e(url('frontend/images/natural-logo.png')); ?>"
                                                                class="img-fluid d-block mx-auto w-50 mt-md-3 mt-2"
                                                                alt="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== End Product Tab Area Wrapper ==-->

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\jatinbeard\resources\views/shop.blade.php ENDPATH**/ ?>