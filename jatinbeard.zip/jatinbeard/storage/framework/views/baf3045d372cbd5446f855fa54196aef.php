<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Jatin Beard Oil - Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Welcome GM Finance - Dashboard" name="description" />
    <meta content="Coderthemes" name="Sandeep"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="">
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-4RPN284KCS"></script>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'G-4RPN284KCS');
    </script>

    <style>
        .table-responsive{
            overflow-x: auto!important;
        }
    </style>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <!-- App css -->
    <link href="<?php echo e(url('admin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"
        id="bootstrap-stylesheet" />
    <link href="<?php echo e(url('admin/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-stylesheet" />
</head>
<?php /**PATH C:\xampp\htdocs\jatinbeardddddssee\resources\views/layouts/components/master.blade.php ENDPATH**/ ?>