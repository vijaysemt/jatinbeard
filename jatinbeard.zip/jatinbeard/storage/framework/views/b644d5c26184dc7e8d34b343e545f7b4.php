<div class="user-box">

    <div class="float-left">
        <img src="<?php echo e(url('frontend/img/jatin-beard-oil-favicon.jpg')); ?>" width="100px" alt=""
            class="avatar-md rounded-circle">
    </div>

    <div class="user-info">
        <a href="#" class="text-capitalize"><?php echo e(Str::limit(Auth::user()->name, '10')); ?></a>
        <p class="text-muted m-0">Administrator</p>
    </div>

</div>

<!--- Sidemenu -->
<div id="sidebar-menu">

    <ul class="metismenu" id="side-menu">

        <li class="menu-title">Navigation</li>

        <li>
            <a href="/home">
                <i class="ti-home"></i>
                <span> Dashboard </span>
            </a>
        </li>

        <li>
            <a href="javascript: void(0);">
                <i class="ti-files"></i>
                <span> Product Manage</span>
                <span class="menu-arrow"></span>
            </a>
            <ul class="nav-second-level" aria-expanded="false">
                <li><a href="/productlist">Product List</a></li>
                <li><a href="/createproduct">Add New Product</a></li>
                <li><a href="/productgall">Product Gallery</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);">
                <i class="ti-files"></i>
                <span> Woocommerce</span>
                <span class="menu-arrow"></span>
            </a>
            <ul class="nav-second-level" aria-expanded="false">
                <li><a href="<?php echo e(url('categorylist')); ?>">Category List</a></li>
                
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);">
                <i class="ti-files"></i>
                <span> CMS Pages</span>
                <span class="menu-arrow"></span>
            </a>
            <ul class="nav-second-level" aria-expanded="false">
                <li><a href="<?php echo e(url('pagelist')); ?>">CMS All pages </a></li>
            </ul>
        </li>

        <li>
            <a href="<?php echo e(url('sliderlist')); ?>">
                <i class="ti-files"></i>
                <span> Slider List</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('topbar')); ?>">
                <i class="ti-files"></i>
                <span> Topbar</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('coupons.index')); ?>">
                <i class="ti-layout-cta-btn-right"></i>
                <span> Coupons</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('orders')); ?>">
                <i class="ti-shopping-cart"></i>
                <span> Orders</span>
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                <i class="mdi mdi-logout-variant"></i>
                <span> Logout </span>
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>

    </ul>

</div>
<?php /**PATH C:\xampp\htdocs\jatinbeard\resources\views/layouts/components/sidebar.blade.php ENDPATH**/ ?>