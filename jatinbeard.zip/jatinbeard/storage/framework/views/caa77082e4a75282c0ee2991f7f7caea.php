<footer style="background: #111" class=" text-md-start text-center text-light py-md-5 py-4">
    <div class="container">
        <div class=" mt-5">
            <div class="row">
                <div class="col-md-3">
                    <p class="text-light mb-3 fw-normal text-uppercase">Newsletter</p>
                    <p class=" mb-3">Sign up to our newsletter to receive exclusive offers</p>

                    <form action="">
                        <div class=" form-group">
                            <input type="text" name="" class="w-100 py-2 mb-3"
                                style="background:transparent; border:1px solid #555;">
                        </div>
                        <button class="btn rounded-0 btn-light px-4"><small> S U B S C R I B E</small></button>

                        <div class="social-widget mt-4">
                            <a href="https://www.facebook.com/profile.php?id=100064825326115" target="_blank"><i
                                    class="fa-brands fa-facebook " target="_blank"></i></a>
                            <a href="https://www.instagram.com/jatinbeard/" target="_blank"><i
                                    class="fa-brands fa-instagram "></i> </a>
                            <a href="https://www.youtube.com/@jatinjatinsharma95" target="_blank"><i
                                    class="fab fa-youtube "></i> </a>
                        </div>
                    </form>
                </div>
                <div class="col-md-2">
                    <div class=" ps-md-5 pt-md-0 pt-5">
                        <p class="text-light mb-3 fw-normal text-uppercase">Quick Link's</p>
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>
                            <li><a href="<?php echo e(url('shop')); ?>">Shop</a></li>
                            <li><a href="<?php echo e(url('contact-us')); ?>">Contact us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class=" ps-md-5 pt-md-0 pt-4">
                        <p class="text-light mb-3 fw-normal text-uppercase">Abour Us</p>
                        <p>Jatin Beard , The People's Brand, is here to offer the best solutions for all your SKIN & HAIR problems. A prominent and homegrown Indian brand, Jatin Beard has brought in sophisticated amenities for our clients in the skin and hair department.</p>
                    </div>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(url('/')); ?>">
                    <img class="logo-main mb-md-4 mt-md-0 mt-4" src="<?php echo e(url('frontend/img/jatin-beard-oil.png')); ?>"
                        alt="Logo" />
                        </a>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="py-5 text-md-start text-center" style="background: #111">
    <div class="container">
        <div class="row">
            <div class="col-md-7 order-md-0  order-1">
                <p class="">© 2023 Jatin Beard Oil. All rights reserved. Designed by <a target="_blank"
                        class="" style="color: #999" href="https://digitalmagnetix.in/"><u>
                            DigitalMagnetix</u></a><br>

                            <span class="text-warning">
                                Disclaimer: The Image is for representation purposes only. The packaging you receive might ARA
                            </span>
                </p>

            </div>
            <div class="col-md-5 text-md-end samll order-md-1 order-0">
                <div class=" mb-md-0 mb-4">
                    <?php $__currentLoopData = App\Models\Cmspage::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class=" ps-md-4 px-2" style="color: #999"
                            href="<?php echo e(url('support/' . $date->id . '/' . $date->name)); ?>"><?php echo e($date->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!--== End Footer Area Wrapper ==-->
<!--== Scroll Top Button ==-->
<div class="scroll-to-top"><span class="icofont-arrow-up"></span></div>
<!--== Start Quick View Menu ==-->

<!--== End Quick View Menu ==-->
<!--== Start Sidebar Cart Menu ==-->

<!--== End Sidebar Cart Menu ==-->
<!--== Start Side Menu ==-->
<aside class="off-canvas-wrapper">
    <div class="off-canvas-inner">
        <div class="off-canvas-overlay d-none"></div>
        <!-- Start Off Canvas Content Wrapper -->
        <div class="off-canvas-content">
            <!-- Off Canvas Header -->
            <div class="off-canvas-header">
                <div class="close-action">
                    <button class="btn-close"><i class="icofont-close-line"></i></button>
                </div>
            </div>
            <div class="off-canvas-item">
                <!-- Start Mobile Menu Wrapper -->
                <div class="res-mobile-menu">
                    <!-- Note Content Auto Generate By Jquery From Main Menu -->
                </div>
                <!-- End Mobile Menu Wrapper -->
            </div>
            <!-- Off Canvas Footer -->
            <div class="off-canvas-footer"></div>
        </div>
        <!-- End Off Canvas Content Wrapper -->
    </div>
</aside>
<!--== End Side Menu ==-->
</div>

<script></script>
<!--=======================Javascript============================-->
<!--=== Modernizr Min Js ===-->
<script src="<?php echo e(url('frontend/js/modernizr.js')); ?>"></script>
<!--=== jQuery Min Js ===-->
<script src="<?php echo e(url('frontend/js/jquery-3.6.0.min.js')); ?>"></script>
<!--=== jQuery Migration Min Js ===-->
<script src="<?php echo e(url('frontend/js/jquery-migrate.js')); ?>"></script>
<!--=== Popper Min Js ===-->
<script src="<?php echo e(url('frontend/js/popper.min.js')); ?>"></script>
<!--=== Bootstrap Min Js ===-->
<script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
<!--=== jquery Appear Js ===-->
<script src="<?php echo e(url('frontend/js/jquery.appear.js')); ?>"></script>
<!--=== jquery Swiper Min Js ===-->
<script src="<?php echo e(url('frontend/js/swiper.min.js')); ?>"></script>
<!--=== jQuery Slick Min Js ===-->
<script src="<?php echo e(url('frontend/js/slick.min.js')); ?>"></script>
<!--=== jquery Fancybox Min Js ===-->
<script src="<?php echo e(url('frontend/js/fancybox.min.js')); ?>"></script>
<!--=== jquery Aos Min Js ===-->
<script src="<?php echo e(url('frontend/js/aos.min.js')); ?>"></script>
<!--=== jquery Slicknav Js ===-->
<script src="<?php echo e(url('frontend/js/jquery.slicknav.js')); ?>"></script>
<!--=== jquery Countdown Js ===-->
<script src="<?php echo e(url('frontend/js/jquery.countdown.min.js')); ?>"></script>
<!--=== jquery Wow Min Js ===-->
<script src="<?php echo e(url('frontend/js/wow.min.js')); ?>"></script>
<!--=== jQuery Zoom Min Js ===-->
<script src="<?php echo e(url('frontend/js/jquery-zoom.min.js')); ?>"></script>
<!--=== Custom Js ===-->
<script src="<?php echo e(url('frontend/js/custom.js')); ?>"></script>
<!--instert link in footer-->
<script src="<?php echo e(url('frontend/js/lightbox.js')); ?>"></script>
<!--instert link in footer-->

</body>

</html>
<?php /**PATH C:\xampp\htdocs\jatinbeardddddssee\resources\views/footer.blade.php ENDPATH**/ ?>