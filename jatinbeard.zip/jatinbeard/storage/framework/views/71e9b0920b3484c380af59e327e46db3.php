<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container my-5">
    <h2 class="mb-4">Shopping Cart</h2>
    <div class="row">
        <div class="col-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>  <img src="<?php echo e(url('admin/assets/uploads/product/home/' . $item->product->pimage)); ?>"
                                    alt="" width="50px"></td>
                                <td><?php echo e($item->product->name); ?></td>
                                <td>
                                    <input type="number" value="<?php echo e($item->quantity); ?>" class="qty-input" data-id="<?php echo e($item->id); ?>" min="1" max="10">
                                </td>
                                <td><?php echo e(number_format($item->product->price, 2)); ?>/-</td>
                                <td class="item-total"><?php echo e(number_format($item->product->price * $item->quantity, 2)); ?>/-</td>
                                <td>
                                    <a href="<?php echo e(route('cart.remove', ['id' => $item->product_id])); ?>" class="btn btn-danger btn-sm">Remove</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-6 text-start">
            <a href="<?php echo e(url('shop')); ?>">
                <button class="btn btn-primary">Back to shop</button>
            </a>
        </div>
        <div class="col-6 text-end">
            <h4>Total: <span id="cart-total"><?php echo e(number_format($total, 1)); ?>/-</span></h4>
            <button class="btn btn-primary" onclick="location.href='/checkout'">Checkout</button>
        </div>
    </div>
</div>



<script>
document.addEventListener('DOMContentLoaded', function() {
    const qtyInputs = document.querySelectorAll('.qty-input');

    qtyInputs.forEach(input => {
        input.addEventListener('change', function() {
            const id = this.dataset.id;
            const qty = this.value;

            fetch('/cart/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({
                    id: id,
                    quantity: qty
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update item total
                    const row = input.closest('tr');
                    row.querySelector('.item-total').innerText = `$${data.itemTotal.toFixed(2)}`;

                    // Update cart total
                    document.getElementById('cart-total').innerText = `${data.cartTotal.toFixed(2)}`;
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
});


</script>


<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\jatinbeardddddssee\resources\views/cart.blade.php ENDPATH**/ ?>